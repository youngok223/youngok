package study6;

public class DoWhileTest {

	public static void main(String[] args) {
		
		// 1 ~ 10
		int a = 1;
		do {
			System.out.println(a);
			a++;
		}while(a <= 10);
		
		System.out.println("\n\n");
		
		int b= 1;
		while(b <= 10) {
			System.out.println(b);
			b++;
		}

	}

}
