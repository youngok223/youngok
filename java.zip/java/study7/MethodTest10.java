package study7;

import java.util.Scanner;

public class MethodTest10 {

	public static void main(String[] args) {
		Scanner scn = new Scanner(System.in);
		System.out.print("크기를 입력하세요(제곱미터단위)>> ");
		int size = scn.nextInt();
		roomSize(size);		
		System.out.println("-----------------------");
		
		myCalc(10, 20, "+");
		System.out.println("-----------------------");
		
		int a = 60;
		int b = 58;
		aa(a, b,"");
		System.out.println("-----------------------");
		
		int[] score = {60,70,80,68,78};
//		System.out.println("점수의 합: " + arraySum(score));
		arraySum(score);
	}
	
	public static void roomSize(int size){
		double result = size * 0.3025;
		System.out.println("입력하신 "+size+"평방미터는 "+(size*0.3025)+"평 입니다.");
		System.out.println("입력하신 "+size+"평방미터는 "+result+"평 입니다.");
	}
	
	public static void myCalc(int a, int b, String c) {
		
		switch(c) {
		case"+":System.out.println(a+b);
		break;
		case"-":System.out.println(a-b);
		break;
		case"*":System.out.println(a*b);
		break;
		case"/":System.out.println(a/b);
		break;
		default:System.out.println("오류");
		}
		//10 + 20 = 30
	}
	
	public static void aa(int a,int b, String c) {
		if(a<=100 && a>=60) {
			c = "합격";
		}else if(a<60 && a>=0) {
			c = "재시험";
		}else {
			c = "잘못 입력";
		}
		if(b<=100 && b>=60) {
			c = "합격";
		}else if(b<60 && b>=0) {
			c = "재시험";
		}else {
			c = "잘못 입력";
		}
		System.out.println("a과목 "+a+", b과목 "+b+"로 "+c+" 입니다.");
	}
	
	public static void arraySum(int[] jumsu) {
//		int aa = jumsu[0]+jumsu[1]+jumsu[2]+jumsu[3]+jumsu[4];
		for(int i= 0;i <= jumsu.length;i++) {
			
//			System.out.println();
		}
		return ;
	}

}
