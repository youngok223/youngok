package study2;

public class Test1 {

	public static void main(String[] args) {
		
		int a = 10;
		int b = 20;
		
		// 30
		System.out.println( a+b );
		
		// 합게는 30입니다.
		System.out.println("합계는 "+ (a + b) + "입니다.");
		
		//실습5
		int dan = 5;
		
		System.out.println(dan+"x1="+(dan*1));
		System.out.println(dan+"x2="+(dan*2));
		System.out.println(dan+"x3="+(dan*3));
		System.out.println(dan+"x4="+(dan*4));
	}

}
