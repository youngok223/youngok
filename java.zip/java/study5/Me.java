package study5;

public class Me {

	public static void main(String[] args) {
		
		for(int i = 1; i <=7; i++) {
			System.out.println("java");
		}

		System.out.println("\n\n");
		
//		--------------------------------------------------------------
		
		for(int i = 11; i <=20; i++) {
			System.out.print(i+" ");
		}
		
		System.out.println("\n\n");
//		--------------------------------------------------------------
		
		for(int i = 1;i <=100; i++) {
			if(i%2==1) {
				System.out.print(i+ " ");
			}
		}
		System.out.println("\n\n");
//☆☆☆☆--------------------------------------------------------------
		
		for(int i=1990; i<=2022;i++) {
			int age= 2025 - i+1;
				System.out.println(i+"년생은 "+age+"세 입니다");
			}
		}
	
	
//-------------------------------------------------------------------
	
		
		
	
	
}
