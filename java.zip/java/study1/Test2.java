package study1;

public class Test2 {
	public static void main(String[] args) {
		System.out.println("@수강과목@");
		System.out.println("<font color='red'>1.JAVA</font>");
		System.out.println("2.ORACLE");
		System.out.println("3.JSP");
		System.out.println("4.jsp&서블릿");
		System.out.println("5.javascript/jquery");
		System.out.println("6.spring boot");
		System.out.println("7.linux");
		System.out.println("8.React");
		System.out.println();
		System.out.println("#자바언어의 특징");
		System.out.println("1.자바언어는 독립적이다");
		System.out.println("2.자바는 고급언어이다");
		System.out.println("3.자바언어는 객체지향 언어이다.");
		System.out.println("4.자바언어는 C와 유사하다.");
	}

}
