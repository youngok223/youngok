package study1;

public class Test1{

/*
 * 첫번째 파일
 */


//	System.out.println("aaaa");
	public static void main(String[] args) {
//		주석이란? 프로그램 내에서 프로그램 수행과 관련없는 설명을 설정할때 사용하는 기호
		// 한줄주석
		/* 여러줄주석 */
		System.out.println("설치 성공!!");
		System.out.println("자바를 시작합니다.");
		System.out.println("오라클을 시작합니다.");
		
		System.out.print("111");
		System.out.println();//단순 개행(줄바꿈)
		System.out.print("222");
		System.out.println();
		System.out.print("333");
	}

}
