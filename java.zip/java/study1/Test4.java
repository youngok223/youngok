package study1;

public class Test4 {

	public static void main(String[] args) {

		int eng = 92;
		int kor = 88;
		int math = 98;
		int hap = eng+kor+math;
		int avh = hap/3;
		
		System.out.println(hap);
		System.out.println(avh);
		System.out.println("--------------");
		
		int number = 77;
		System.out.print("77을 10으로 나눈 나머지 값은?");
		System.out.print(number%10);//7
		System.out.println("입니다.");
		System.out.println("--------------");
		System.out.println(number%8);//5
		
		
		

		/*
		 * System.out.println(eng + kor+ math);
		 * System.out.println(eng -kor);
		 * System.out.println(eng*2);
		 * System.out.println(eng/2);
		 */

	}

}
